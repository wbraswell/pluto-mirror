/* pluto start (n) */
for (i=0; i<n; i++) {
    for (j=0; j<n; j++) {
        a[i][j] = b[i][j] + 1;
    }
}

/* pluto end */
