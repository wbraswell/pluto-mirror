#include <piplib/piplib.h>
#include <stdio.h> /* various function declarations use FILE */
#include "type.h"
#include "sol.h"
#include "tab.h"
#include "funcall.h"
