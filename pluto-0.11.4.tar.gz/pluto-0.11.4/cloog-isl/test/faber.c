/* Generated from ./test/faber.cloog by CLooG v1.0.0 64 bits in 1.78s. */
/* CLooG asked for 548 KBytes. */
for (idx4=0;idx4<=10;idx4++) {
  for (idx5=-6;idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
  }
  for (idx6=-8*(1);idx6<=floord(-6*idx4+77*1+923,77);idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx6=ceild(-6*idx4+77*1+924,77);idx6<=floord(6*1+72,6);idx6++) {
    S3(idx5 = 1) ;
    S6(idx5 = 1) ;
  }
  for (idx6=ceild(6*1+73,6);idx6<=-8*(1)+24;idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx6=ceild(-3*idx4+14*1+672,14);idx6<=floord(3*1+144,3);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx5=2;idx5<=18;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),-8*idx5+25);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-1;idx5++) {
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  S3(idx5 = 0,idx6 = 0) ;
  S10(idx5 = 0,idx6 = 0) ;
  for (idx6=13;idx6<=24;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=1;idx6<=floord(-6*idx4+923,77);idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(-6*idx4+924,77);idx6<=12;idx6++) {
    S3(idx5 = 0) ;
    S6(idx5 = 0) ;
  }
  for (idx6=ceild(-3*idx4+672,14);idx6<=48;idx6++) {
    S1(idx5 = 0) ;
  }
  for (idx5=19;idx5<=24;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
  }
}
for (idx4=11;idx4<=12;idx4++) {
  for (idx5=-6;idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx6=-8*(1);idx6<=floord(-6*idx4+77*1+923,77);idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx6=ceild(-3*idx4+14*1+672,14);idx6<=floord(3*1+144,3);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx6=ceild(-6*idx4+77*1+924,77);idx6<=floord(6*1+72,6);idx6++) {
    S3(idx5 = 1) ;
    S6(idx5 = 1) ;
  }
  for (idx6=ceild(6*1+73,6);idx6<=-8*(1)+24;idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx5=max(ceild(2*idx4+309,231),2);idx5<=18;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),-8*idx5+25);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=19;idx5<=24;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-4;idx5++) {
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=-3;idx5<=floord(2*idx4-42,7);idx5++) {
    for (idx6=6;idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(2*idx4-41,7);idx5<=-1;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  S3(idx5 = 0,idx6 = 0) ;
  S10(idx5 = 0,idx6 = 0) ;
  for (idx6=13;idx6<=24;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=1;idx6<=floord(-6*idx4+923,77);idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(-6*idx4+924,77);idx6<=12;idx6++) {
    S3(idx5 = 0) ;
    S6(idx5 = 0) ;
  }
  for (idx6=ceild(-3*idx4+672,14);idx6<=48;idx6++) {
    S1(idx5 = 0) ;
  }
}
for (idx4=13;idx4<=17;idx4++) {
  for (idx5=-6;idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx6=-8*(1);idx6<=floord(-6*idx4+77*1+923,77);idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx6=ceild(-3*idx4+14*1+672,14);idx6<=floord(3*1+144,3);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx6=ceild(-6*idx4+77*1+924,77);idx6<=floord(6*1+72,6);idx6++) {
    S3(idx5 = 1) ;
    S6(idx5 = 1) ;
  }
  for (idx6=ceild(6*1+73,6);idx6<=-8*(1)+24;idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx5=ceild(2*idx4+309,231);idx5<=18;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),-8*idx5+25);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(6*idx4+1387,77);idx5<=24;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-4;idx5++) {
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=-3;idx5<=floord(2*idx4-42,7);idx5++) {
    for (idx6=6;idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(2*idx4-41,7);idx5<=-1;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  S3(idx5 = 0,idx6 = 0) ;
  S10(idx5 = 0,idx6 = 0) ;
  for (idx6=13;idx6<=24;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=1;idx6<=floord(-6*idx4+923,77);idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(-6*idx4+924,77);idx6<=12;idx6++) {
    S3(idx5 = 0) ;
    S6(idx5 = 0) ;
  }
  for (idx6=ceild(-3*idx4+672,14);idx6<=48;idx6++) {
    S1(idx5 = 0) ;
  }
  for (idx5=2;idx5<=floord(2*idx4+308,231);idx5++) {
    for (idx6=-8*idx5;idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=-8*idx5+24;idx6++) {
      S3 ;
      S6 ;
    }
    for (idx6=-8*idx5+25;idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=30;idx6++) {
      S6 ;
    }
  }
}
for (idx4=18;idx4<=20;idx4++) {
  for (idx5=-6;idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx6=-8*(1);idx6<=floord(-6*idx4+77*1+923,77);idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx6=ceild(-3*idx4+14*1+672,14);idx6<=floord(3*1+144,3);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx6=ceild(-6*idx4+77*1+924,77);idx6<=floord(6*1+72,6);idx6++) {
    S3(idx5 = 1) ;
    S6(idx5 = 1) ;
  }
  for (idx6=ceild(6*1+73,6);idx6<=-8*(1)+24;idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx5=ceild(2*idx4+309,231);idx5<=18;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),-8*idx5+25);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(6*idx4+1387,77);idx5<=24;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-4;idx5++) {
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=-3;idx5<=-1;idx5++) {
    for (idx6=6;idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  S3(idx5 = 0,idx6 = 0) ;
  S10(idx5 = 0,idx6 = 0) ;
  for (idx6=13;idx6<=24;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=1;idx6<=floord(-6*idx4+923,77);idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(-6*idx4+924,77);idx6<=12;idx6++) {
    S3(idx5 = 0) ;
    S6(idx5 = 0) ;
  }
  for (idx6=ceild(-3*idx4+672,14);idx6<=48;idx6++) {
    S1(idx5 = 0) ;
  }
  for (idx5=2;idx5<=floord(2*idx4+308,231);idx5++) {
    for (idx6=-8*idx5;idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=-8*idx5+24;idx6++) {
      S3 ;
      S6 ;
    }
    for (idx6=-8*idx5+25;idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=30;idx6++) {
      S6 ;
    }
  }
}
for (idx4=21;idx4<=27;idx4++) {
  for (idx5=-6;idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx6=-8*(1);idx6<=floord(-6*idx4+77*1+923,77);idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx6=ceild(-3*idx4+14*1+672,14);idx6<=floord(3*1+144,3);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx6=ceild(-6*idx4+77*1+924,77);idx6<=floord(6*1+72,6);idx6++) {
    S3(idx5 = 1) ;
    S6(idx5 = 1) ;
  }
  for (idx6=ceild(6*1+73,6);idx6<=-8*(1)+24;idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx5=ceild(2*idx4+309,231);idx5<=18;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),-8*idx5+25);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(6*idx4+1387,77);idx5<=24;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-4;idx5++) {
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=-3;idx5<=-1;idx5++) {
    for (idx6=6;idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  S3(idx5 = 0,idx6 = 0) ;
  S10(idx5 = 0,idx6 = 0) ;
  for (idx6=1;idx6<=5;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=6;idx6<=floord(2*idx4+84,21);idx6++) {
    S3(idx5 = 0) ;
    S7(idx5 = 0) ;
  }
  for (idx6=13;idx6<=24;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(2*idx4+85,21);idx6<=7;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=8;idx6<=floord(-6*idx4+923,77);idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(-6*idx4+924,77);idx6<=12;idx6++) {
    S3(idx5 = 0) ;
    S6(idx5 = 0) ;
  }
  for (idx6=ceild(-3*idx4+672,14);idx6<=48;idx6++) {
    S1(idx5 = 0) ;
  }
  for (idx5=2;idx5<=floord(2*idx4+308,231);idx5++) {
    for (idx6=-8*idx5;idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=-8*idx5+24;idx6++) {
      S3 ;
      S6 ;
    }
    for (idx6=-8*idx5+25;idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=30;idx6++) {
      S6 ;
    }
  }
}
for (idx4=28;idx4<=33;idx4++) {
  for (idx5=-6;idx5<=-4;idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx6=-8*(1);idx6<=floord(-6*idx4+77*1+923,77);idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx6=ceild(-3*idx4+14*1+672,14);idx6<=floord(3*1+144,3);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx6=ceild(-6*idx4+77*1+924,77);idx6<=floord(6*1+72,6);idx6++) {
    S3(idx5 = 1) ;
    S6(idx5 = 1) ;
  }
  for (idx6=ceild(6*1+73,6);idx6<=-8*(1)+24;idx6++) {
    S3(idx5 = 1) ;
  }
  for (idx5=ceild(2*idx4+309,231);idx5<=18;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),-8*idx5+25);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(6*idx4+1387,77);idx5<=24;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
  }
  for (idx5=-3;idx5<=-1;idx5++) {
    for (idx6=6;idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  S3(idx5 = 0,idx6 = 0) ;
  S10(idx5 = 0,idx6 = 0) ;
  for (idx6=1;idx6<=5;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=6;idx6<=floord(2*idx4+84,21);idx6++) {
    S3(idx5 = 0) ;
    S7(idx5 = 0) ;
  }
  for (idx6=13;idx6<=24;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(2*idx4+85,21);idx6<=7;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=8;idx6<=floord(-6*idx4+923,77);idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(-6*idx4+924,77);idx6<=12;idx6++) {
    S3(idx5 = 0) ;
    S6(idx5 = 0) ;
  }
  for (idx6=ceild(-3*idx4+672,14);idx6<=48;idx6++) {
    S1(idx5 = 0) ;
  }
  for (idx5=2;idx5<=floord(2*idx4+308,231);idx5++) {
    for (idx6=-8*idx5;idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=-8*idx5+24;idx6++) {
      S3 ;
      S6 ;
    }
    for (idx6=-8*idx5+25;idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=30;idx6++) {
      S6 ;
    }
  }
}
for (idx5=-6;idx5<=-4;idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+72,6);idx6++) {
    S6(idx4 = 34) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 34) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+144,3);idx6++) {
    S1(idx4 = 34) ;
  }
}
for (idx6=-8*(1);idx6<=floord(-6*(34)+77*1+923,77);idx6++) {
  S3(idx4 = 34,idx5 = 1) ;
}
for (idx6=ceild(-3*(34)+14*1+672,14);idx6<=floord(3*1+144,3);idx6++) {
  S1(idx4 = 34,idx5 = 1) ;
}
for (idx6=ceild(-6*(34)+77*1+924,77);idx6<=floord(6*1+72,6);idx6++) {
  S3(idx4 = 34,idx5 = 1) ;
  S6(idx4 = 34,idx5 = 1) ;
}
for (idx6=ceild(6*1+73,6);idx6<=-8*(1)+24;idx6++) {
  S3(idx4 = 34,idx5 = 1) ;
}
for (idx5=ceild(2*34+309,231);idx5<=18;idx5++) {
  for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
    S3(idx4 = 34) ;
  }
  for (idx6=ceild(-3*(34)+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
    S1(idx4 = 34) ;
  }
  for (idx6=max(ceild(-6*(34)+77*idx5+924,77),-8*idx5+25);idx6<=floord(6*idx5+72,6);idx6++) {
    S6(idx4 = 34) ;
  }
}
for (idx5=ceild(6*34+1387,77);idx5<=24;idx5++) {
  for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
    S3(idx4 = 34) ;
  }
}
for (idx5=-3;idx5<=-1;idx5++) {
  for (idx6=6;idx6<=min(floord(4*idx5+72,10),floord(2*34-7*idx5+84,21));idx6++) {
    S7(idx4 = 34) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(34)+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
    S6(idx4 = 34) ;
  }
  for (idx6=ceild(-3*(34)+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
    S1(idx4 = 34) ;
  }
}
S3(idx4 = 34,idx5 = 0,idx6 = 0) ;
S10(idx4 = 34,idx5 = 0,idx6 = 0) ;
for (idx6=1;idx6<=5;idx6++) {
  S3(idx4 = 34,idx5 = 0) ;
}
for (idx6=6;idx6<=min(7,floord(2*34+84,21));idx6++) {
  S3(idx4 = 34,idx5 = 0) ;
  S7(idx4 = 34,idx5 = 0) ;
}
for (idx6=13;idx6<=24;idx6++) {
  S3(idx4 = 34,idx5 = 0) ;
}
for (idx6=8;idx6<=floord(-6*(34)+923,77);idx6++) {
  S3(idx4 = 34,idx5 = 0) ;
}
for (idx6=ceild(-6*(34)+924,77);idx6<=12;idx6++) {
  S3(idx4 = 34,idx5 = 0) ;
  S6(idx4 = 34,idx5 = 0) ;
}
for (idx6=ceild(-3*(34)+672,14);idx6<=48;idx6++) {
  S1(idx4 = 34,idx5 = 0) ;
}
for (idx5=2;idx5<=floord(2*34+308,231);idx5++) {
  for (idx6=-8*idx5;idx6<=floord(-6*(34)+77*idx5+923,77);idx6++) {
    S3(idx4 = 34) ;
  }
  for (idx6=ceild(-3*(34)+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
    S1(idx4 = 34) ;
  }
  for (idx6=ceild(-6*(34)+77*idx5+924,77);idx6<=-8*idx5+24;idx6++) {
    S3(idx4 = 34) ;
    S6(idx4 = 34) ;
  }
  for (idx6=-8*idx5+25;idx6<=floord(6*idx5+72,6);idx6++) {
    S6(idx4 = 34) ;
  }
}
for (idx5=19;idx5<=floord(6*34+1386,77);idx5++) {
  for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
    S3(idx4 = 34) ;
  }
  for (idx6=ceild(-6*(34)+77*idx5+924,77);idx6<=30;idx6++) {
    S6(idx4 = 34) ;
  }
}
for (idx4=35;idx4<=36;idx4++) {
  for (idx5=-6;idx5<=-4;idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=1;idx5++) {
    for (idx6=-8*idx5;idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(6*idx5+72,6);idx6++) {
      S3 ;
      S6 ;
    }
    for (idx6=ceild(6*idx5+73,6);idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
  }
  for (idx5=ceild(2*idx4+309,231);idx5<=18;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),-8*idx5+25);idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(6*idx4+1387,77);idx5<=24;idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
  }
  for (idx5=-3;idx5<=-1;idx5++) {
    for (idx6=6;idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  S3(idx5 = 0,idx6 = 0) ;
  S10(idx5 = 0,idx6 = 0) ;
  for (idx6=1;idx6<=5;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=6;idx6<=min(7,floord(2*idx4+84,21));idx6++) {
    S3(idx5 = 0) ;
    S7(idx5 = 0) ;
  }
  for (idx6=13;idx6<=24;idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=8;idx6<=floord(-6*idx4+923,77);idx6++) {
    S3(idx5 = 0) ;
  }
  for (idx6=ceild(-6*idx4+924,77);idx6<=12;idx6++) {
    S3(idx5 = 0) ;
    S6(idx5 = 0) ;
  }
  for (idx6=ceild(-3*idx4+672,14);idx6<=48;idx6++) {
    S1(idx5 = 0) ;
  }
  for (idx5=1;idx5<=floord(idx4-21,14);idx5++) {
    for (idx6=-8*idx5;idx6<=floord(2*idx5+11,2);idx6++) {
      S3 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(2*idx4-7*idx5+84,21);idx6++) {
      S3 ;
      S7 ;
    }
    for (idx6=ceild(2*idx4-7*idx5+85,21);idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S3 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(6*idx5+72,6);idx6++) {
      S3 ;
      S6 ;
    }
    for (idx6=ceild(6*idx5+73,6);idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
  }
  for (idx5=2;idx5<=floord(2*idx4+308,231);idx5++) {
    for (idx6=-8*idx5;idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S3 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(3*idx5+144,3);idx6++) {
      S1 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=-8*idx5+24;idx6++) {
      S3 ;
      S6 ;
    }
    for (idx6=-8*idx5+25;idx6<=floord(6*idx5+72,6);idx6++) {
      S6 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=-8*idx5;idx6<=-8*idx5+24;idx6++) {
      S3 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=30;idx6++) {
      S6 ;
    }
  }
}
for (idx4=37;idx4<=41;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=-4;idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=-3;idx5<=floord(idx4-21,14);idx5++) {
    for (idx6=max(6,ceild(2*idx5+12,2));idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=18;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=30;idx6++) {
      S6 ;
    }
  }
}
for (idx4=42;idx4<=44;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4-21,14);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=-3;idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-1;idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(idx4-42,77);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx4=45;idx4<=46;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4-21,14);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=-3;idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-1;idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(idx4-42,77);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=1;idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx4=47;idx4<=46;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4-21,14);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=-3;idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-1;idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(30*idx4-1382,231);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(30*idx4-1381,231);idx5<=floord(idx4-42,77);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=1;idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx5=ceild(47-120,14);idx5<=floord(10*47-823,77);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 47) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
}
for (idx5=ceild(47-41,14);idx5<=floord(47-21,14);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*47-7*idx5+84,21));idx6++) {
    S7(idx4 = 47) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(47)+77*idx5+924,77));idx6<=floord(-6*(47)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 47) ;
  }
  for (idx6=ceild(-3*(47)+14*idx5+672,14);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
}
for (idx5=19;idx5<=floord(6*47+1386,77);idx5++) {
  for (idx6=ceild(-6*(47)+77*idx5+924,77);idx6<=min(floord(-6*(47)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 47) ;
  }
}
for (idx5=ceild(10*47-822,77);idx5<=floord(10*47-697,77);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(47)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 47) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 47) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
}
for (idx5=ceild(47-20,14);idx5<=5;idx5++) {
  for (idx6=ceild(-6*(47)+77*idx5+924,77);idx6<=floord(-6*(47)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 47) ;
  }
  for (idx6=ceild(-3*(47)+14*idx5+672,14);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=6;idx6<=min(floord(47+42,14),idx5);idx6++) {
    S5(idx4 = 47) ;
  }
  for (idx6=ceild(-6*(47)+77*idx5+924,77);idx6<=floord(-6*(47)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 47) ;
  }
  for (idx6=ceild(-3*(47)+14*idx5+672,14);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
}
for (idx5=ceild(10*47-696,77);idx5<=floord(47-84,14);idx5++) {
  for (idx6=max(ceild(2*47-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 47) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(47)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 47) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 47) ;
  }
}
for (idx5=ceild(47-83,14);idx5<=-1;idx5++) {
  for (idx6=max(ceild(2*47-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 47) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(47)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 47) ;
  }
  for (idx6=ceild(-3*(47)+14*idx5+672,14);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
}
for (idx5=0;idx5<=floord(47-42,77);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 47) ;
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(-6*(47)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 47) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(47)+77*idx5+924,77));idx6<=floord(-6*(47)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 47) ;
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(-3*(47)+14*idx5+672,14);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
}
for (idx5=1;idx5<=floord(47-42,14);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 47) ;
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(-6*(47)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(47)+77*idx5+923,77);idx6++) {
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(-6*(47)+77*idx5+924,77);idx6<=floord(-6*(47)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 47) ;
    S9(idx4 = 47) ;
  }
  for (idx6=ceild(-3*(47)+14*idx5+672,14);idx6<=floord(-3*(47)+14*idx5+780,14);idx6++) {
    S1(idx4 = 47) ;
  }
}
for (idx5=ceild(48-120,14);idx5<=floord(10*48-823,77);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 48) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=ceild(48-41,14);idx5<=floord(48-21,14);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*48-7*idx5+84,21));idx6++) {
    S7(idx4 = 48) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(48)+77*idx5+924,77));idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
  }
  for (idx6=ceild(-3*(48)+14*idx5+672,14);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=19;idx5<=floord(6*48+1386,77);idx5++) {
  for (idx6=ceild(-6*(48)+77*idx5+924,77);idx6<=min(floord(-6*(48)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 48) ;
  }
}
for (idx5=ceild(10*48-822,77);idx5<=floord(10*48-697,77);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 48) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=ceild(48-20,14);idx5<=5;idx5++) {
  for (idx6=ceild(-6*(48)+77*idx5+924,77);idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
  }
  for (idx6=ceild(-3*(48)+14*idx5+672,14);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=6;idx6<=min(floord(48+42,14),idx5);idx6++) {
    S5(idx4 = 48) ;
  }
  for (idx6=ceild(-6*(48)+77*idx5+924,77);idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
  }
  for (idx6=ceild(-3*(48)+14*idx5+672,14);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=ceild(10*48-696,77);idx5<=floord(48-84,14);idx5++) {
  for (idx6=max(ceild(2*48-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 48) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 48) ;
  }
}
for (idx5=ceild(48-83,14);idx5<=-1;idx5++) {
  for (idx6=max(ceild(2*48-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 48) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
  }
  for (idx6=ceild(-3*(48)+14*idx5+672,14);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=0;idx5<=floord(48-42,77);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 48) ;
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(-6*(48)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(48)+77*idx5+924,77));idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(-3*(48)+14*idx5+672,14);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=1;idx5<=floord(30*48-1382,231);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 48) ;
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(-6*(48)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(48)+77*idx5+924,77));idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(-3*(48)+14*idx5+672,14);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=ceild(30*48-1381,231);idx5<=min(floord(-2*(48)+114,35),floord(48-42,14));idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 48) ;
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(-6*(48)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(48)+77*idx5+923,77);idx6++) {
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(-6*(48)+77*idx5+924,77);idx6<=floord(-6*(48)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 48) ;
    S9(idx4 = 48) ;
  }
  for (idx6=ceild(-3*(48)+14*idx5+672,14);idx6<=floord(-3*(48)+14*idx5+780,14);idx6++) {
    S1(idx4 = 48) ;
  }
}
for (idx5=ceild(49-120,14);idx5<=floord(10*49-823,77);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 49) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=ceild(49-41,14);idx5<=min(floord(49-21,14),2);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*49-7*idx5+84,21));idx6++) {
    S7(idx4 = 49) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(49)+77*idx5+924,77));idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
  }
  for (idx6=ceild(-3*(49)+14*idx5+672,14);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=19;idx5<=floord(6*49+1386,77);idx5++) {
  for (idx6=ceild(-6*(49)+77*idx5+924,77);idx6<=min(floord(-6*(49)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 49) ;
  }
}
for (idx5=ceild(10*49-822,77);idx5<=floord(10*49-697,77);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 49) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=ceild(49-20,14);idx5<=5;idx5++) {
  for (idx6=ceild(-6*(49)+77*idx5+924,77);idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
  }
  for (idx6=ceild(-3*(49)+14*idx5+672,14);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=6;idx6<=min(floord(49+42,14),idx5);idx6++) {
    S5(idx4 = 49) ;
  }
  for (idx6=ceild(-6*(49)+77*idx5+924,77);idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
  }
  for (idx6=ceild(-3*(49)+14*idx5+672,14);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=ceild(10*49-696,77);idx5<=floord(49-84,14);idx5++) {
  for (idx6=max(ceild(2*49-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 49) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 49) ;
  }
}
for (idx5=ceild(49-83,14);idx5<=-1;idx5++) {
  for (idx6=max(ceild(2*49-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 49) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
  }
  for (idx6=ceild(-3*(49)+14*idx5+672,14);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=0;idx5<=floord(49-42,77);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 49) ;
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-6*(49)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(49)+77*idx5+924,77));idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-3*(49)+14*idx5+672,14);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=1;idx5<=floord(30*49-1382,231);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 49) ;
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-6*(49)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(49)+77*idx5+924,77));idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-3*(49)+14*idx5+672,14);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=ceild(30*49-1381,231);idx5<=floord(-2*(49)+114,35);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 49) ;
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-6*(49)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(49)+77*idx5+923,77);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-6*(49)+77*idx5+924,77);idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-3*(49)+14*idx5+672,14);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx5=ceild(-2*(49)+115,35);idx5<=floord(49-42,14);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*49-7*idx5+11,21);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(2*49-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 49) ;
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-6*(49)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(49)+77*idx5+923,77);idx6++) {
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-6*(49)+77*idx5+924,77);idx6<=floord(-6*(49)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 49) ;
    S9(idx4 = 49) ;
  }
  for (idx6=ceild(-3*(49)+14*idx5+672,14);idx6<=floord(-3*(49)+14*idx5+780,14);idx6++) {
    S1(idx4 = 49) ;
  }
}
for (idx4=50;idx4<=49;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=2;idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-696,77);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-1;idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(idx4-42,77);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=1;idx5<=min(floord(-2*idx4+114,35),floord(30*idx4-1382,231));idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=max(ceild(-2*idx4+115,35),ceild(30*idx4-1381,231));idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx4-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+923,77);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx5=ceild(50-120,14);idx5<=floord(10*50-823,77);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 50) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=ceild(50-41,14);idx5<=2;idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*50-7*idx5+84,21));idx6++) {
    S7(idx4 = 50) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(50)+77*idx5+924,77));idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
  }
  for (idx6=ceild(-3*(50)+14*idx5+672,14);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=19;idx5<=floord(6*50+1386,77);idx5++) {
  for (idx6=ceild(-6*(50)+77*idx5+924,77);idx6<=min(floord(-6*(50)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 50) ;
  }
}
for (idx5=ceild(10*50-822,77);idx5<=floord(10*50-697,77);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 50) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=ceild(50-20,14);idx5<=5;idx5++) {
  for (idx6=ceild(-6*(50)+77*idx5+924,77);idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
  }
  for (idx6=ceild(-3*(50)+14*idx5+672,14);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=6;idx6<=min(floord(50+42,14),idx5);idx6++) {
    S5(idx4 = 50) ;
  }
  for (idx6=ceild(-6*(50)+77*idx5+924,77);idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
  }
  for (idx6=ceild(-3*(50)+14*idx5+672,14);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=ceild(10*50-696,77);idx5<=floord(50-84,14);idx5++) {
  for (idx6=max(ceild(2*50-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 50) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 50) ;
  }
}
for (idx5=ceild(50-83,14);idx5<=-1;idx5++) {
  for (idx6=max(ceild(2*50-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 50) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
  }
  for (idx6=ceild(-3*(50)+14*idx5+672,14);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=0;idx5<=floord(50-42,77);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 50) ;
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-6*(50)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(50)+77*idx5+924,77));idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-3*(50)+14*idx5+672,14);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=1;idx5<=floord(-2*(50)+114,35);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 50) ;
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-6*(50)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(50)+77*idx5+924,77));idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-3*(50)+14*idx5+672,14);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=ceild(-2*(50)+115,35);idx5<=floord(30*50-1382,231);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*50-7*idx5+11,21);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(2*50-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 50) ;
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-6*(50)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(50)+77*idx5+924,77));idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-3*(50)+14*idx5+672,14);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx5=ceild(30*50-1381,231);idx5<=floord(50-42,14);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*50-7*idx5+11,21);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(2*50-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 50) ;
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-6*(50)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(50)+77*idx5+923,77);idx6++) {
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-6*(50)+77*idx5+924,77);idx6<=floord(-6*(50)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 50) ;
    S9(idx4 = 50) ;
  }
  for (idx6=ceild(-3*(50)+14*idx5+672,14);idx6<=floord(-3*(50)+14*idx5+780,14);idx6++) {
    S1(idx4 = 50) ;
  }
}
for (idx4=51;idx4<=52;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=2;idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-696,77);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-1;idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(idx4-42,77);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=1;idx5<=floord(-2*idx4+114,35);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(-2*idx4+115,35);idx5<=min(floord(30*idx4-1382,231),floord(idx4-42,14));idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx4-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx5=ceild(53-120,14);idx5<=floord(10*53-823,77);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 53) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=ceild(53-41,14);idx5<=2;idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*53-7*idx5+84,21));idx6++) {
    S7(idx4 = 53) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(53)+77*idx5+924,77));idx6<=floord(-6*(53)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 53) ;
  }
  for (idx6=ceild(-3*(53)+14*idx5+672,14);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=19;idx5<=floord(6*53+1386,77);idx5++) {
  for (idx6=ceild(-6*(53)+77*idx5+924,77);idx6<=min(floord(-6*(53)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 53) ;
  }
}
for (idx5=ceild(10*53-822,77);idx5<=floord(53-84,14);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(53)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 53) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 53) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=ceild(53-20,14);idx5<=5;idx5++) {
  for (idx6=ceild(-6*(53)+77*idx5+924,77);idx6<=floord(-6*(53)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 53) ;
  }
  for (idx6=ceild(-3*(53)+14*idx5+672,14);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=6;idx6<=min(floord(53+42,14),idx5);idx6++) {
    S5(idx4 = 53) ;
  }
  for (idx6=ceild(-6*(53)+77*idx5+924,77);idx6<=floord(-6*(53)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 53) ;
  }
  for (idx6=ceild(-3*(53)+14*idx5+672,14);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=max(ceild(53-83,14),ceild(10*53-696,77));idx5<=-1;idx5++) {
  for (idx6=max(ceild(2*53-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 53) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(53)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 53) ;
  }
  for (idx6=ceild(-3*(53)+14*idx5+672,14);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=0;idx5<=floord(53-42,77);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 53) ;
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(-6*(53)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(53)+77*idx5+924,77));idx6<=floord(-6*(53)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 53) ;
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(-3*(53)+14*idx5+672,14);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=1;idx5<=floord(-2*(53)+114,35);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 53) ;
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(-6*(53)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(53)+77*idx5+924,77));idx6<=floord(-6*(53)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 53) ;
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(-3*(53)+14*idx5+672,14);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=ceild(-2*(53)+115,35);idx5<=floord(53-42,14);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*53-7*idx5+11,21);idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(2*53-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 53) ;
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(-6*(53)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 53) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(53)+77*idx5+924,77));idx6<=floord(-6*(53)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 53) ;
    S9(idx4 = 53) ;
  }
  for (idx6=ceild(-3*(53)+14*idx5+672,14);idx6<=floord(-3*(53)+14*idx5+780,14);idx6++) {
    S1(idx4 = 53) ;
  }
}
for (idx5=ceild(54-120,14);idx5<=floord(10*54-823,77);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 54) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=ceild(54-41,14);idx5<=2;idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*54-7*idx5+84,21));idx6++) {
    S7(idx4 = 54) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(54)+77*idx5+924,77));idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
  }
  for (idx6=ceild(-3*(54)+14*idx5+672,14);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=19;idx5<=floord(6*54+1386,77);idx5++) {
  for (idx6=ceild(-6*(54)+77*idx5+924,77);idx6<=min(floord(-6*(54)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 54) ;
  }
}
for (idx5=ceild(10*54-822,77);idx5<=floord(54-84,14);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 54) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=ceild(54-20,14);idx5<=5;idx5++) {
  for (idx6=ceild(-6*(54)+77*idx5+924,77);idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
  }
  for (idx6=ceild(-3*(54)+14*idx5+672,14);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=6;idx6<=min(floord(54+42,14),idx5);idx6++) {
    S5(idx4 = 54) ;
  }
  for (idx6=ceild(-6*(54)+77*idx5+924,77);idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
  }
  for (idx6=ceild(-3*(54)+14*idx5+672,14);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=ceild(54-83,14);idx5<=floord(10*54-697,77);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
  }
  for (idx6=ceild(-3*(54)+14*idx5+672,14);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=ceild(10*54-696,77);idx5<=-1;idx5++) {
  for (idx6=max(ceild(2*54-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 54) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
  }
  for (idx6=ceild(-3*(54)+14*idx5+672,14);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=0;idx5<=floord(54-42,77);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 54) ;
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(-6*(54)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(54)+77*idx5+924,77));idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(-3*(54)+14*idx5+672,14);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=1;idx5<=floord(-2*(54)+114,35);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 54) ;
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(-6*(54)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(54)+77*idx5+924,77));idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(-3*(54)+14*idx5+672,14);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx5=ceild(-2*(54)+115,35);idx5<=floord(54-42,14);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*54-7*idx5+11,21);idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(2*54-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 54) ;
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(-6*(54)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 54) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(54)+77*idx5+924,77));idx6<=floord(-6*(54)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 54) ;
    S9(idx4 = 54) ;
  }
  for (idx6=ceild(-3*(54)+14*idx5+672,14);idx6<=floord(-3*(54)+14*idx5+780,14);idx6++) {
    S1(idx4 = 54) ;
  }
}
for (idx4=55;idx4<=54;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=2;idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-696,77);idx5<=-1;idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=min(floord(-2*idx4+114,35),floord(idx4-42,77));idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=max(ceild(-2*idx4+115,35),ceild(4*idx4-207,56));idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx4-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx5=ceild(55-120,14);idx5<=floord(10*55-823,77);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 55) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=ceild(55-41,14);idx5<=2;idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*55-7*idx5+84,21));idx6++) {
    S7(idx4 = 55) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(55)+77*idx5+924,77));idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
  }
  for (idx6=ceild(-3*(55)+14*idx5+672,14);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=19;idx5<=floord(6*55+1386,77);idx5++) {
  for (idx6=ceild(-6*(55)+77*idx5+924,77);idx6<=min(floord(-6*(55)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 55) ;
  }
}
for (idx5=ceild(10*55-822,77);idx5<=floord(55-84,14);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 55) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=ceild(55-20,14);idx5<=5;idx5++) {
  for (idx6=ceild(-6*(55)+77*idx5+924,77);idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
  }
  for (idx6=ceild(-3*(55)+14*idx5+672,14);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=6;idx6<=min(floord(55+42,14),idx5);idx6++) {
    S5(idx4 = 55) ;
  }
  for (idx6=ceild(-6*(55)+77*idx5+924,77);idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
  }
  for (idx6=ceild(-3*(55)+14*idx5+672,14);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=ceild(55-83,14);idx5<=floord(10*55-697,77);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
  }
  for (idx6=ceild(-3*(55)+14*idx5+672,14);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=ceild(10*55-696,77);idx5<=-1;idx5++) {
  for (idx6=max(ceild(2*55-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 55) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
  }
  for (idx6=ceild(-3*(55)+14*idx5+672,14);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=0;idx5<=floord(-2*(55)+114,35);idx5++) {
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 55) ;
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(-6*(55)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(55)+77*idx5+924,77));idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(-3*(55)+14*idx5+672,14);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=ceild(-2*(55)+115,35);idx5<=floord(4*55-208,56);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*55-7*idx5+11,21);idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=max(ceild(2*55-7*idx5+12,21),ceild(2*idx5+12,2));idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 55) ;
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(-6*(55)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(-3*(55)+14*idx5+672,14);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx5=ceild(4*55-207,56);idx5<=floord(55-42,14);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*55-7*idx5+11,21);idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(2*55-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 55) ;
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(-6*(55)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 55) ;
  }
  for (idx6=max(ceild(12*idx5+252,30),ceild(-6*(55)+77*idx5+924,77));idx6<=floord(-6*(55)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 55) ;
    S9(idx4 = 55) ;
  }
  for (idx6=ceild(-3*(55)+14*idx5+672,14);idx6<=floord(-3*(55)+14*idx5+780,14);idx6++) {
    S1(idx4 = 55) ;
  }
}
for (idx4=56;idx4<=57;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=2;idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+211,14);idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-696,77);idx5<=-1;idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(-2*idx4+114,35);idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(-2*idx4+115,35);idx5<=floord(4*idx4-208,56);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),ceild(2*idx5+12,2));idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(4*idx4-207,56);idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx4-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(idx4+210,14);idx5++) {
    for (idx6=idx5-12;idx6<=floord(idx4+42,14);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
  }
}
for (idx4=58;idx4<=61;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=2;idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+211,14);idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-696,77);idx5<=-1;idx5++) {
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),6);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(4*idx4-208,56);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),ceild(2*idx5+12,2));idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(4*idx4-207,56);idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx4-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(idx4+210,14);idx5++) {
    for (idx6=idx5-12;idx6<=floord(idx4+42,14);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
  }
}
for (idx5=-4;idx5<=-3;idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 62) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(62)+14*idx5+780,14);idx6++) {
    S1(idx4 = 62) ;
  }
}
for (idx6=ceild(2*2+12,2);idx6<=min(floord(4*2+72,10),floord(2*62-7*(2)+84,21));idx6++) {
  S7(idx4 = 62,idx5 = 2) ;
}
for (idx6=max(ceild(12*2+252,30),ceild(-6*(62)+77*2+924,77));idx6<=floord(-6*(62)+77*2+1140,77);idx6++) {
  S6(idx4 = 62,idx5 = 2) ;
}
for (idx6=ceild(-3*(62)+14*2+672,14);idx6<=floord(-3*(62)+14*2+780,14);idx6++) {
  S1(idx4 = 62,idx5 = 2) ;
}
for (idx5=20;idx5<=22;idx5++) {
  for (idx6=ceild(-6*(62)+77*idx5+924,77);idx6<=min(floord(-6*(62)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 62) ;
  }
}
for (idx6=ceild(12*-2+252,30);idx6<=floord(-6*(62)+77*-2+1140,77);idx6++) {
  S6(idx4 = 62,idx5 = -2) ;
}
for (idx6=-2+24;idx6<=-2*(-2)+24;idx6++) {
  S2(idx4 = 62,idx5 = -2) ;
}
for (idx6=ceild(-6*(-2)+90,3);idx6<=floord(-3*(62)+14*-2+780,14);idx6++) {
  S1(idx4 = 62,idx5 = -2) ;
}
for (idx5=3;idx5<=5;idx5++) {
  for (idx6=ceild(-6*(62)+77*idx5+924,77);idx6<=floord(-6*(62)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 62) ;
  }
  for (idx6=ceild(-3*(62)+14*idx5+672,14);idx6<=floord(-3*(62)+14*idx5+780,14);idx6++) {
    S1(idx4 = 62) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=6;idx6<=min(floord(62+42,14),idx5);idx6++) {
    S5(idx4 = 62) ;
  }
  for (idx6=ceild(-6*(62)+77*idx5+924,77);idx6<=floord(-6*(62)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 62) ;
  }
  for (idx6=ceild(-3*(62)+14*idx5+672,14);idx6<=floord(-3*(62)+14*idx5+780,14);idx6++) {
    S1(idx4 = 62) ;
  }
}
for (idx6=ceild(12*-1+252,30);idx6<=floord(-6*(62)+77*-1+1140,77);idx6++) {
  S6(idx4 = 62,idx5 = -1) ;
}
for (idx6=ceild(-3*(62)+14*-1+672,14);idx6<=floord(-3*(62)+14*-1+780,14);idx6++) {
  S1(idx4 = 62,idx5 = -1) ;
}
for (idx6=-2*(0)+6;idx6<=floord(2*62-7*(0)+11,21);idx6++) {
  S9(idx4 = 62,idx5 = 0) ;
}
for (idx6=max(ceild(2*62-7*(0)+12,21),ceild(2*0+12,2));idx6<=floord(4*0+72,10);idx6++) {
  S7(idx4 = 62,idx5 = 0) ;
  S9(idx4 = 62,idx5 = 0) ;
}
for (idx6=ceild(4*0+73,10);idx6<=floord(12*0+251,30);idx6++) {
  S9(idx4 = 62,idx5 = 0) ;
}
for (idx6=ceild(-6*(62)+77*0+1141,77);idx6<=-2*(0)+24;idx6++) {
  S9(idx4 = 62,idx5 = 0) ;
}
for (idx6=ceild(12*0+252,30);idx6<=floord(-6*(62)+77*0+1140,77);idx6++) {
  S6(idx4 = 62,idx5 = 0) ;
  S9(idx4 = 62,idx5 = 0) ;
}
for (idx6=ceild(-3*(62)+14*0+672,14);idx6<=floord(-3*(62)+14*0+780,14);idx6++) {
  S1(idx4 = 62,idx5 = 0) ;
}
for (idx6=-2*(1)+6;idx6<=floord(2*62-7*(1)+11,21);idx6++) {
  S9(idx4 = 62,idx5 = 1) ;
}
for (idx6=ceild(2*62-7*(1)+12,21);idx6<=floord(2*1+11,2);idx6++) {
  S9(idx4 = 62,idx5 = 1) ;
}
for (idx6=ceild(2*1+12,2);idx6<=floord(4*1+72,10);idx6++) {
  S7(idx4 = 62,idx5 = 1) ;
  S9(idx4 = 62,idx5 = 1) ;
}
for (idx6=ceild(4*1+73,10);idx6<=floord(12*1+251,30);idx6++) {
  S9(idx4 = 62,idx5 = 1) ;
}
for (idx6=ceild(-6*(62)+77*1+1141,77);idx6<=-2*(1)+24;idx6++) {
  S9(idx4 = 62,idx5 = 1) ;
}
for (idx6=max(ceild(12*1+252,30),ceild(-6*(62)+77*1+924,77));idx6<=floord(-6*(62)+77*1+1140,77);idx6++) {
  S6(idx4 = 62,idx5 = 1) ;
  S9(idx4 = 62,idx5 = 1) ;
}
for (idx6=ceild(-3*(62)+14*1+672,14);idx6<=floord(-3*(62)+14*1+780,14);idx6++) {
  S1(idx4 = 62,idx5 = 1) ;
}
for (idx6=19-12;idx6<=floord(62+42,14);idx6++) {
  S5(idx4 = 62,idx5 = 19) ;
}
for (idx6=ceild(-6*(62)+77*19+924,77);idx6<=floord(-6*(62)+77*19+1140,77);idx6++) {
  S6(idx4 = 62,idx5 = 19) ;
}
for (idx4=63;idx4<=69;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=2;idx5++) {
    for (idx6=ceild(2*idx5+12,2);idx6<=min(floord(4*idx5+72,10),floord(2*idx4-7*idx5+84,21));idx6++) {
      S7 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+211,14);idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-20,14);idx5<=5;idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=6;idx6<=min(floord(idx4+42,14),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=-1;idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(4*idx4-208,56);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),ceild(2*idx5+12,2));idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(4*idx4-207,56);idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx4-7*idx5+12,21);idx6<=floord(2*idx5+11,2);idx6++) {
      S9 ;
    }
    for (idx6=ceild(2*idx5+12,2);idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=3;idx5<=floord(idx4-21,14);idx5++) {
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=floord(idx4+210,14);idx5++) {
    for (idx6=idx5-12;idx6<=floord(idx4+42,14);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+924,77);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
  }
}
for (idx4=70;idx4<=76;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=6;idx5<=18;idx5++) {
    for (idx6=max(ceild(idx4+6,14),6);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=0;idx5<=floord(10*idx4-697,77);idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx6=2;idx6<=7;idx6++) {
    S9(idx5 = 2) ;
  }
  S7(idx5 = 2,idx6 = 8) ;
  S9(idx5 = 2,idx6 = 8) ;
  S8(idx5 = 2,idx6 = 26) ;
  S9(idx5 = 2,idx6 = 9) ;
  for (idx6=10;idx6<=floord(-6*idx4+1294,77);idx6++) {
    S6(idx5 = 2) ;
    S9(idx5 = 2) ;
  }
  for (idx6=ceild(-6*idx4+1295,77);idx6<=20;idx6++) {
    S9(idx5 = 2) ;
  }
  for (idx6=ceild(-3*idx4+700,14);idx6<=floord(-3*idx4+808,14);idx6++) {
    S1(idx5 = 2) ;
  }
  for (idx5=3;idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=max(max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77)),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=20;idx5++) {
    for (idx6=idx5-12;idx6<=min(floord(-idx5+36,2),floord(idx4+42,14));idx6++) {
      S5 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx5=21;idx5<=floord(6*idx4+1386,77);idx5++) {
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(10*idx4-696,77);idx5<=1;idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(2*idx4-7*idx5+11,21);idx6++) {
      S9 ;
    }
    for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=max(ceild(2*idx4-7*idx5+12,21),ceild(2*idx5+12,2));idx6<=floord(4*idx5+72,10);idx6++) {
      S7 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(6*idx4+1387,77);idx5<=24;idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
}
for (idx5=ceild(77-120,14);idx5<=floord(10*77-823,77);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 77) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(77)+14*idx5+780,14);idx6++) {
    S1(idx4 = 77) ;
  }
}
for (idx5=ceild(77-83,14);idx5<=floord(77-79,14);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(77)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+672,14);idx6<=floord(-3*(77)+14*idx5+780,14);idx6++) {
    S1(idx4 = 77) ;
  }
}
for (idx5=6;idx5<=18;idx5++) {
  for (idx6=max(ceild(77+6,14),6);idx6<=min(min(floord(-idx5+36,2),floord(77+42,14)),idx5);idx6++) {
    S5(idx4 = 77) ;
  }
  for (idx6=max(ceild(-6*(77)+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*(77)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
    S8(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+672,14);idx6<=floord(-3*(77)+14*idx5+780,14);idx6++) {
    S1(idx4 = 77) ;
  }
}
for (idx5=ceild(10*77-822,77);idx5<=floord(77-84,14);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(77)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 77) ;
  }
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 77) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(77)+14*idx5+780,14);idx6++) {
    S1(idx4 = 77) ;
  }
}
for (idx5=0;idx5<=floord(10*77-697,77);idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 77) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(77)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 77) ;
    S9(idx4 = 77) ;
  }
  for (idx6=ceild(-6*(77)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+672,14);idx6<=floord(-3*(77)+14*idx5+780,14);idx6++) {
    S1(idx4 = 77) ;
  }
}
for (idx6=2;idx6<=7;idx6++) {
  S9(idx4 = 77,idx5 = 2) ;
}
S7(idx4 = 77,idx5 = 2,idx6 = 8) ;
S9(idx4 = 77,idx5 = 2,idx6 = 8) ;
S8(idx4 = 77,idx5 = 2,idx6 = 26) ;
S9(idx4 = 77,idx5 = 2,idx6 = 9) ;
for (idx6=10;idx6<=floord(-6*(77)+1294,77);idx6++) {
  S6(idx4 = 77,idx5 = 2) ;
  S9(idx4 = 77,idx5 = 2) ;
}
for (idx6=ceild(-6*(77)+1295,77);idx6<=20;idx6++) {
  S9(idx4 = 77,idx5 = 2) ;
}
for (idx6=ceild(-3*(77)+700,14);idx6<=floord(-3*(77)+808,14);idx6++) {
  S1(idx4 = 77,idx5 = 2) ;
}
for (idx5=3;idx5<=floord(77+5,14);idx5++) {
  for (idx6=max(max(ceild(12*idx5+252,30),ceild(-6*(77)+77*idx5+924,77)),ceild(6*idx5+36,6));idx6<=floord(-6*(77)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
    S8(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+672,14);idx6<=floord(-3*(77)+14*idx5+780,14);idx6++) {
    S1(idx4 = 77) ;
  }
}
for (idx5=19;idx5<=20;idx5++) {
  for (idx6=idx5-12;idx6<=min(floord(-idx5+36,2),floord(77+42,14));idx6++) {
    S5(idx4 = 77) ;
  }
  for (idx6=max(ceild(-6*(77)+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*(77)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
    S8(idx4 = 77) ;
  }
}
for (idx5=21;idx5<=24;idx5++) {
  for (idx6=max(ceild(-6*(77)+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=min(floord(-6*(77)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
    S8(idx4 = 77) ;
  }
}
for (idx5=ceild(10*77-696,77);idx5<=1;idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(2*77-7*idx5+11,21);idx6++) {
    S9(idx4 = 77) ;
  }
  for (idx6=ceild(4*idx5+73,10);idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 77) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(77)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 77) ;
    S9(idx4 = 77) ;
  }
  for (idx6=max(ceild(2*77-7*idx5+12,21),ceild(2*idx5+12,2));idx6<=floord(4*idx5+72,10);idx6++) {
    S7(idx4 = 77) ;
    S9(idx4 = 77) ;
  }
  for (idx6=ceild(-6*(77)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 77) ;
  }
  for (idx6=ceild(-3*(77)+14*idx5+672,14);idx6<=floord(-3*(77)+14*idx5+780,14);idx6++) {
    S1(idx4 = 77) ;
  }
}
for (idx4=78;idx4<=80;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=max(6,ceild(idx4+6,14));idx5<=18;idx5++) {
    for (idx6=max(ceild(idx4+6,14),6);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=max(0,ceild(idx4-78,14));idx5<=1;idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx6=2;idx6<=7;idx6++) {
    S9(idx5 = 2) ;
  }
  S7(idx5 = 2,idx6 = 8) ;
  S9(idx5 = 2,idx6 = 8) ;
  S8(idx5 = 2,idx6 = 26) ;
  S9(idx5 = 2,idx6 = 9) ;
  for (idx6=10;idx6<=floord(-6*idx4+1294,77);idx6++) {
    S6(idx5 = 2) ;
    S9(idx5 = 2) ;
  }
  for (idx6=ceild(-6*idx4+1295,77);idx6<=20;idx6++) {
    S9(idx5 = 2) ;
  }
  for (idx6=ceild(-3*idx4+700,14);idx6<=floord(-3*idx4+808,14);idx6++) {
    S1(idx5 = 2) ;
  }
  for (idx5=3;idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=max(max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77)),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=20;idx5++) {
    for (idx6=idx5-12;idx6<=min(floord(-idx5+36,2),floord(idx4+42,14));idx6++) {
      S5 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx5=21;idx5<=24;idx5++) {
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
}
for (idx5=ceild(81-120,14);idx5<=floord(81-84,14);idx5++) {
  for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
    S2(idx4 = 81) ;
  }
  for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*(81)+14*idx5+780,14);idx6++) {
    S1(idx4 = 81) ;
  }
}
for (idx5=max(ceild(10*81-822,77),ceild(81-83,14));idx5<=floord(81-79,14);idx5++) {
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(81)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 81) ;
  }
  for (idx6=ceild(-3*(81)+14*idx5+672,14);idx6<=floord(-3*(81)+14*idx5+780,14);idx6++) {
    S1(idx4 = 81) ;
  }
}
for (idx5=ceild(81+6,14);idx5<=18;idx5++) {
  for (idx6=max(ceild(81+6,14),6);idx6<=min(min(floord(-idx5+36,2),floord(81+42,14)),idx5);idx6++) {
    S5(idx4 = 81) ;
  }
  for (idx6=max(ceild(-6*(81)+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*(81)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 81) ;
  }
  for (idx6=ceild(-3*(81)+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
    S8(idx4 = 81) ;
  }
  for (idx6=ceild(-3*(81)+14*idx5+672,14);idx6<=floord(-3*(81)+14*idx5+780,14);idx6++) {
    S1(idx4 = 81) ;
  }
}
for (idx5=ceild(81-78,14);idx5<=1;idx5++) {
  for (idx6=-2*idx5+6;idx6<=floord(12*idx5+251,30);idx6++) {
    S9(idx4 = 81) ;
  }
  for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*(81)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 81) ;
    S9(idx4 = 81) ;
  }
  for (idx6=ceild(-6*(81)+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
    S9(idx4 = 81) ;
  }
  for (idx6=ceild(-3*(81)+14*idx5+672,14);idx6<=floord(-3*(81)+14*idx5+780,14);idx6++) {
    S1(idx4 = 81) ;
  }
}
for (idx6=2;idx6<=7;idx6++) {
  S9(idx4 = 81,idx5 = 2) ;
}
S7(idx4 = 81,idx5 = 2,idx6 = 8) ;
S9(idx4 = 81,idx5 = 2,idx6 = 8) ;
S8(idx4 = 81,idx5 = 2,idx6 = 26) ;
S9(idx4 = 81,idx5 = 2,idx6 = 9) ;
for (idx6=10;idx6<=floord(-6*(81)+1294,77);idx6++) {
  S6(idx4 = 81,idx5 = 2) ;
  S9(idx4 = 81,idx5 = 2) ;
}
for (idx6=ceild(-6*(81)+1295,77);idx6<=20;idx6++) {
  S9(idx4 = 81,idx5 = 2) ;
}
for (idx6=ceild(-3*(81)+700,14);idx6<=floord(-3*(81)+808,14);idx6++) {
  S1(idx4 = 81,idx5 = 2) ;
}
for (idx5=3;idx5<=floord(81+5,14);idx5++) {
  for (idx6=max(max(ceild(12*idx5+252,30),ceild(-6*(81)+77*idx5+924,77)),ceild(6*idx5+36,6));idx6<=floord(-6*(81)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 81) ;
  }
  for (idx6=ceild(-3*(81)+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
    S8(idx4 = 81) ;
  }
  for (idx6=ceild(-3*(81)+14*idx5+672,14);idx6<=floord(-3*(81)+14*idx5+780,14);idx6++) {
    S1(idx4 = 81) ;
  }
}
for (idx5=19;idx5<=20;idx5++) {
  for (idx6=idx5-12;idx6<=min(floord(-idx5+36,2),floord(81+42,14));idx6++) {
    S5(idx4 = 81) ;
  }
  for (idx6=max(ceild(-6*(81)+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*(81)+77*idx5+1140,77);idx6++) {
    S6(idx4 = 81) ;
  }
  for (idx6=ceild(-3*(81)+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
    S8(idx4 = 81) ;
  }
}
for (idx5=21;idx5<=24;idx5++) {
  for (idx6=max(ceild(-6*(81)+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=min(floord(-6*(81)+77*idx5+1140,77),30);idx6++) {
    S6(idx4 = 81) ;
  }
  for (idx6=ceild(-3*(81)+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
    S8(idx4 = 81) ;
  }
}
for (idx4=82;idx4<=83;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(idx4-84,14);idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=max(ceild(idx4+6,14),6);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-78,14);idx5<=1;idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx6=2;idx6<=7;idx6++) {
    S9(idx5 = 2) ;
  }
  S7(idx5 = 2,idx6 = 8) ;
  S9(idx5 = 2,idx6 = 8) ;
  S8(idx5 = 2,idx6 = 26) ;
  S9(idx5 = 2,idx6 = 9) ;
  for (idx6=10;idx6<=floord(-6*idx4+1294,77);idx6++) {
    S6(idx5 = 2) ;
    S9(idx5 = 2) ;
  }
  for (idx6=ceild(-6*idx4+1295,77);idx6<=20;idx6++) {
    S9(idx5 = 2) ;
  }
  for (idx6=ceild(-3*idx4+700,14);idx6<=floord(-3*idx4+808,14);idx6++) {
    S1(idx5 = 2) ;
  }
  for (idx5=3;idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=max(max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77)),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=20;idx5++) {
    for (idx6=idx5-12;idx6<=min(floord(-idx5+36,2),floord(idx4+42,14));idx6++) {
      S5 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx5=21;idx5<=24;idx5++) {
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
}
for (idx4=84;idx4<=85;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=0;idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=max(ceild(idx4+6,14),6);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-83,14);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-78,14);idx5<=1;idx5++) {
    for (idx6=-2*idx5+6;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx6=2;idx6<=7;idx6++) {
    S9(idx5 = 2) ;
  }
  S7(idx5 = 2,idx6 = 8) ;
  S9(idx5 = 2,idx6 = 8) ;
  S8(idx5 = 2,idx6 = 26) ;
  S9(idx5 = 2,idx6 = 9) ;
  for (idx6=10;idx6<=floord(-6*idx4+1294,77);idx6++) {
    S6(idx5 = 2) ;
    S9(idx5 = 2) ;
  }
  for (idx6=ceild(-6*idx4+1295,77);idx6<=20;idx6++) {
    S9(idx5 = 2) ;
  }
  for (idx6=ceild(-3*idx4+700,14);idx6<=floord(-3*idx4+808,14);idx6++) {
    S1(idx5 = 2) ;
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=max(max(ceild(12*idx5+252,30),ceild(-6*idx4+77*idx5+924,77)),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=20;idx5++) {
    for (idx6=idx5-12;idx6<=min(floord(-idx5+36,2),floord(idx4+42,14));idx6++) {
      S5 ;
    }
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx5=21;idx5<=24;idx5++) {
    for (idx6=max(ceild(-6*idx4+77*idx5+924,77),ceild(6*idx5+36,6));idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx5=3;idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx4=86;idx4<=89;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=0;idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=20;idx5++) {
    for (idx6=max(ceild(idx4+6,14),idx5-12);idx6<=floord(-idx5+36,2);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx6=4;idx6<=8;idx6++) {
    S9(idx5 = 1) ;
  }
  for (idx6=ceild(-3*idx4+686,14);idx6<=floord(-3*idx4+794,14);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx6=9;idx6<=floord(-6*idx4+1217,77);idx6++) {
    S6(idx5 = 1) ;
    S9(idx5 = 1) ;
  }
  for (idx6=ceild(-6*idx4+1218,77);idx6<=22;idx6++) {
    S9(idx5 = 1) ;
  }
  for (idx5=2;idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=max(ceild(12*idx5+252,30),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=21;idx5<=24;idx5++) {
    for (idx6=ceild(6*idx5+36,6);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
}
for (idx4=90;idx4<=92;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=0;idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=20;idx5++) {
    for (idx6=max(ceild(idx4+6,14),idx5-12);idx6<=floord(-idx5+36,2);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx6=4;idx6<=22;idx6++) {
    S9(idx5 = 1) ;
  }
  for (idx6=ceild(-3*idx4+686,14);idx6<=floord(-3*idx4+794,14);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx5=2;idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=max(ceild(12*idx5+252,30),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=21;idx5<=24;idx5++) {
    for (idx6=ceild(6*idx5+36,6);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
}
for (idx4=93;idx4<=97;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=0;idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=20;idx5++) {
    for (idx6=max(ceild(idx4+6,14),idx5-12);idx6<=floord(-idx5+36,2);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
  for (idx6=ceild(-3*idx4+686,14);idx6<=floord(-3*idx4+794,14);idx6++) {
    S1(idx5 = 1) ;
  }
  for (idx5=2;idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=max(ceild(12*idx5+252,30),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+672,14);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=21;idx5<=24;idx5++) {
    for (idx6=ceild(6*idx5+36,6);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(3*idx5+72,3);idx6++) {
      S8 ;
    }
  }
}
for (idx4=98;idx4<=101;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=0;idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=min(4,floord(idx4-42,14));idx5++) {
    for (idx6=idx5;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=20;idx5++) {
    for (idx6=max(ceild(idx4+6,14),idx5-12);idx6<=floord(-idx5+36,2);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(-13*idx4+3479,105);idx5<=floord(-idx4+251,7);idx5++) {
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(-idx4+252,7);idx5<=24;idx5++) {
    for (idx6=max(ceild(-3*idx5+126,6),ceild(3*idx5-36,3));idx6<=floord(3*idx4+14*idx5-462,14);idx6++) {
      S4 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=42;idx5++) {
    for (idx6=ceild(3*idx5-36,3);idx6<=min(floord(3*idx4+14*idx5-462,14),30);idx6++) {
      S4 ;
    }
  }
  for (idx5=1;idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=max(max(ceild(-6*idx5+90,3),ceild(-3*idx4+14*idx5+672,14)),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=2;idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx4=102;idx4<=113;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=0;idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(10*idx4-822,77);idx5<=4;idx5++) {
    for (idx6=idx5;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=max(ceild(12*idx5+252,30),ceild(6*idx5+36,6));idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=min(20,floord(-idx4+246,7));idx5++) {
    for (idx6=max(ceild(idx4+6,14),idx5-12);idx6<=floord(-idx5+36,2);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(-13*idx4+3479,105);idx5<=floord(-idx4+251,7);idx5++) {
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(-idx4+252,7);idx5<=24;idx5++) {
    for (idx6=max(ceild(-3*idx5+126,6),ceild(3*idx5-36,3));idx6<=floord(3*idx4+14*idx5-462,14);idx6++) {
      S4 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=min(floord(-6*idx4+77*idx5+1140,77),30);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=42;idx5++) {
    for (idx6=ceild(3*idx5-36,3);idx6<=min(floord(3*idx4+14*idx5-462,14),30);idx6++) {
      S4 ;
    }
  }
  for (idx5=1;idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=max(max(ceild(-6*idx5+90,3),ceild(-3*idx4+14*idx5+672,14)),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=max(ceild(idx4-78,14),2);idx5<=floord(10*idx4-823,77);idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=5;idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=floord(12*idx5+251,30);idx6++) {
      S9 ;
    }
    for (idx6=ceild(12*idx5+252,30);idx6<=floord(6*idx5+35,6);idx6++) {
      S9 ;
    }
    for (idx6=ceild(6*idx5+36,6);idx6<=floord(-6*idx4+77*idx5+1140,77);idx6++) {
      S6 ;
      S9 ;
    }
    for (idx6=ceild(-6*idx4+77*idx5+1141,77);idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=min(floord(-3*idx4+14*idx5+654,14),floord(3*idx5+72,3));idx6++) {
      S8 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+672,14),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx4=114;idx4<=118;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=0;idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=1;idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=max(ceild(-6*idx5+90,3),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-78,14);idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(-idx4+252,7);idx5<=24;idx5++) {
    for (idx6=max(ceild(-3*idx5+126,6),ceild(3*idx5-36,3));idx6<=floord(3*idx4+14*idx5-462,14);idx6++) {
      S4 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=42;idx5++) {
    for (idx6=ceild(3*idx5-36,3);idx6<=min(floord(3*idx4+14*idx5-462,14),30);idx6++) {
      S4 ;
    }
  }
  for (idx5=19;idx5<=floord(-idx4+251,7);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
}
for (idx4=119;idx4<=120;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=0;idx5++) {
    for (idx6=idx5+24;idx6<=-2*idx5+24;idx6++) {
      S2 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=1;idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=max(ceild(-6*idx5+90,3),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-78,14);idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=18;idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=24;idx5++) {
    for (idx6=max(ceild(-3*idx5+126,6),ceild(3*idx5-36,3));idx6<=floord(3*idx4+14*idx5-462,14);idx6++) {
      S4 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=42;idx5++) {
    for (idx6=ceild(3*idx5-36,3);idx6<=min(floord(3*idx4+14*idx5-462,14),30);idx6++) {
      S4 ;
    }
  }
}
for (idx4=121;idx4<=125;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=max(ceild(-6*idx5+90,3),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-78,14);idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=floord(-idx4+246,7);idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(-idx4+247,7);idx5<=18;idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=24;idx5++) {
    for (idx6=max(max(ceild(-3*idx5+126,6),ceild(3*idx4+14*idx5-570,14)),ceild(3*idx5-36,3));idx6<=floord(3*idx4+14*idx5-462,14);idx6++) {
      S4 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=42;idx5++) {
    for (idx6=max(ceild(3*idx4+14*idx5-570,14),ceild(3*idx5-36,3));idx6<=min(floord(3*idx4+14*idx5-462,14),30);idx6++) {
      S4 ;
    }
  }
}
for (idx4=126;idx4<=148;idx4++) {
  for (idx5=ceild(idx4-120,14);idx5<=floord(idx4-79,14);idx5++) {
    for (idx6=max(ceild(-6*idx5+90,3),ceild(3*idx5+72,3));idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-78,14);idx5<=floord(idx4-42,14);idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=floord(-idx4+246,7);idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(min(floord(-idx5+36,2),floord(idx4+42,14)),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=ceild(-idx4+247,7);idx5<=floord(-idx4+251,7);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
  for (idx5=19;idx5<=24;idx5++) {
    for (idx6=max(max(ceild(-3*idx5+126,6),ceild(3*idx4+14*idx5-570,14)),ceild(3*idx5-36,3));idx6<=floord(3*idx4+14*idx5-462,14);idx6++) {
      S4 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=min(42,floord(-3*idx4+990,14));idx5++) {
    for (idx6=max(ceild(3*idx4+14*idx5-570,14),ceild(3*idx5-36,3));idx6<=min(floord(3*idx4+14*idx5-462,14),30);idx6++) {
      S4 ;
    }
  }
  for (idx5=ceild(-idx4+252,7);idx5<=18;idx5++) {
    for (idx6=ceild(-3*idx5+126,6);idx6<=floord(3*idx4+14*idx5-462,14);idx6++) {
      S4 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
    for (idx6=ceild(3*idx5+72,3);idx6<=floord(-3*idx4+14*idx5+780,14);idx6++) {
      S1 ;
    }
  }
}
for (idx4=149;idx4<=162;idx4++) {
  for (idx5=ceild(idx4-78,14);idx5<=min(floord(idx4-42,14),8);idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(idx4-41,14);idx5<=floord(idx4+5,14);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(idx4+6,14);idx5<=floord(-idx4+246,7);idx5++) {
    for (idx6=ceild(idx4+6,14);idx6<=min(floord(-idx5+36,2),idx5);idx6++) {
      S5 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(-idx4+247,7);idx5<=floord(-11*idx4+2965,91);idx5++) {
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=max(14,ceild(-idx4+252,7));idx5<=24;idx5++) {
    for (idx6=max(ceild(-3*idx5+126,6),ceild(3*idx4+14*idx5-570,14));idx6<=min(floord(3*idx4+14*idx5-462,14),floord(3*idx5,3));idx6++) {
      S4 ;
    }
    for (idx6=ceild(-3*idx4+14*idx5+546,14);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=floord(-3*idx4+990,14);idx5++) {
    for (idx6=ceild(3*idx4+14*idx5-570,14);idx6<=min(min(floord(3*idx4+14*idx5-462,14),30),floord(3*idx5,3));idx6++) {
      S4 ;
    }
  }
}
for (idx4=163;idx4<=181;idx4++) {
  for (idx5=ceild(idx4-78,14);idx5<=8;idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=floord(-3*idx4+990,14);idx5++) {
    for (idx6=ceild(3*idx4+14*idx5-570,14);idx6<=min(30,floord(3*idx5,3));idx6++) {
      S4 ;
    }
  }
  for (idx5=9;idx5<=13;idx5++) {
    for (idx6=max(max(ceild(-6*idx5+90,3),ceild(-3*idx4+14*idx5+546,14)),ceild(3*idx5,3));idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=14;idx5<=24;idx5++) {
    for (idx6=max(ceild(3*idx4+14*idx5-570,14),ceild(-3*idx5+126,6));idx6<=floord(3*idx5,3);idx6++) {
      S4 ;
    }
    for (idx6=max(ceild(-3*idx4+14*idx5+546,14),ceild(3*idx5+1,3));idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
}
for (idx4=182;idx4<=188;idx4++) {
  for (idx5=ceild(idx4-78,14);idx5<=8;idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=floord(-3*idx4+990,14);idx5++) {
    for (idx6=ceild(3*idx4+14*idx5-570,14);idx6<=min(30,floord(3*idx5,3));idx6++) {
      S4 ;
    }
  }
  for (idx5=9;idx5<=13;idx5++) {
    for (idx6=max(max(ceild(-6*idx5+90,3),ceild(-3*idx4+14*idx5+546,14)),ceild(3*idx5,3));idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=14;idx5<=floord(6*idx4+1471,183);idx5++) {
    S4(idx6 = idx5) ;
    S8(idx6 = idx5) ;
    for (idx6=ceild(3*idx5+1,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(6*idx4+1472,183);idx5<=24;idx5++) {
    for (idx6=max(ceild(3*idx4+14*idx5-570,14),ceild(-3*idx5+126,6));idx6<=floord(-3*idx4+61*idx5+545,61);idx6++) {
      S4 ;
    }
    S4(idx6 = idx5) ;
    S8(idx6 = idx5) ;
    for (idx6=ceild(3*idx5+1,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
}
for (idx4=189;idx4<=190;idx4++) {
  for (idx5=ceild(idx4-78,14);idx5<=8;idx5++) {
    for (idx6=idx5;idx6<=-2*idx5+24;idx6++) {
      S9 ;
    }
    for (idx6=ceild(-6*idx5+90,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=25;idx5<=floord(-3*idx4+990,14);idx5++) {
    for (idx6=ceild(3*idx4+14*idx5-570,14);idx6<=min(30,floord(3*idx5,3));idx6++) {
      S4 ;
    }
  }
  for (idx5=9;idx5<=13;idx5++) {
    for (idx6=max(max(ceild(-6*idx5+90,3),ceild(-3*idx4+14*idx5+546,14)),ceild(3*idx5,3));idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=14;idx5<=floord(6*idx4+1471,183);idx5++) {
    S4(idx6 = idx5) ;
    S8(idx6 = idx5) ;
    for (idx6=ceild(3*idx5+1,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
  for (idx5=ceild(6*idx4+1472,183);idx5<=24;idx5++) {
    S4(idx6 = idx5) ;
    S8(idx6 = idx5) ;
    for (idx6=ceild(3*idx5+1,3);idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
}
for (idx4=191;idx4<=218;idx4++) {
  for (idx5=ceild(idx4-78,14);idx5<=24;idx5++) {
    for (idx6=max(ceild(-6*idx5+90,3),ceild(3*idx5,3));idx6<=floord(-3*idx4+14*idx5+654,14);idx6++) {
      S8 ;
    }
  }
}
