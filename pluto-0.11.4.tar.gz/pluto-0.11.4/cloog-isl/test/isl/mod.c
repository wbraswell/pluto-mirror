/* Generated from ../../../git/cloog/test/isl/mod.cloog by CLooG 0.14.0-325-g71fa959 gmp bits in 0.00s. */
for (i=0;i<=3;i++) {
  if (i%3 <= 1) {
    S1(i);
  }
}
