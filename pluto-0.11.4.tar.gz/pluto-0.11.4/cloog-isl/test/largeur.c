/* Generated from ../../../git/cloog/test/largeur.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.00s. */
if (M >= 1) {
  for (c1=1;c1<=M;c1++) {
    for (c2=1;c2<=c1;c2++) {
      S1(c2,c1) ;
    }
  }
}
