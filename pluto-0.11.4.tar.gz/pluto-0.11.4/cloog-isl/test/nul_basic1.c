/* Generated from ./nul_basic1.cloog by CLooG 0.18.1-2-g43fc508 gmp bits in 0.00s. */
if (M >= 0) {
  for (i=0;i<=M;i+=2) {
    S1(i,(i/2));
  }
}
